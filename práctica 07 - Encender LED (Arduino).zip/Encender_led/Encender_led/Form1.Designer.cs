﻿namespace Encender_led
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cerrar = new System.Windows.Forms.Button();
            this.bApagar = new System.Windows.Forms.Button();
            this.bEncender = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Cerrar
            // 
            this.Cerrar.Location = new System.Drawing.Point(721, 12);
            this.Cerrar.Name = "Cerrar";
            this.Cerrar.Size = new System.Drawing.Size(67, 40);
            this.Cerrar.TabIndex = 0;
            this.Cerrar.Text = "Cerrar";
            this.Cerrar.UseVisualStyleBackColor = true;
            this.Cerrar.Click += new System.EventHandler(this.CerrarForm);
            // 
            // bApagar
            // 
            this.bApagar.Font = new System.Drawing.Font("Myanmar Text", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bApagar.ForeColor = System.Drawing.Color.IndianRed;
            this.bApagar.Location = new System.Drawing.Point(129, 145);
            this.bApagar.Name = "bApagar";
            this.bApagar.Size = new System.Drawing.Size(200, 129);
            this.bApagar.TabIndex = 1;
            this.bApagar.Text = "APAGAR";
            this.bApagar.UseVisualStyleBackColor = true;
            this.bApagar.Click += new System.EventHandler(this.bApagar_Click);
            // 
            // bEncender
            // 
            this.bEncender.Font = new System.Drawing.Font("Myanmar Text", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bEncender.ForeColor = System.Drawing.Color.ForestGreen;
            this.bEncender.Location = new System.Drawing.Point(419, 145);
            this.bEncender.Name = "bEncender";
            this.bEncender.Size = new System.Drawing.Size(200, 129);
            this.bEncender.TabIndex = 2;
            this.bEncender.Text = "ENCENDER";
            this.bEncender.UseVisualStyleBackColor = true;
            this.bEncender.Click += new System.EventHandler(this.bEncender_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.bEncender);
            this.Controls.Add(this.bApagar);
            this.Controls.Add(this.Cerrar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Cerrar;
        private System.Windows.Forms.Button bApagar;
        private System.Windows.Forms.Button bEncender;
    }
}

