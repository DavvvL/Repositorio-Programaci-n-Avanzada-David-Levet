﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Conersor_a_Texto_C_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void Bguardar_Click(object sender, EventArgs e)
        {
            String nombre = Tnombre.Text;
            String apellidos = Tapellidos.Text;
            String telefono = Ttelefono.Text;
            String estatura = Testatura.Text;
            String edad = Tedad.Text;
            String sexo = " ";
            if (Rhombre.Checked)
            {
                sexo = "Hombre";
            }
            else if(Rmujer.Checked)
            {
                sexo = "Mujer";
            }

            String datos = $"Nombres {nombre}\r\nApellidos: {apellidos}\r\nTelefono: {telefono}\r\nEstatura: {estatura}\r\nEdad: {edad}\r\nSexo: {sexo}";

            String rutaArchivo = "C:/Users/Hackerman/Documents/datos.txt";
            bool archivoExiste = File.Exists(rutaArchivo);

            using (StreamWriter writer = new StreamWriter(rutaArchivo, true))
            {
                if (archivoExiste)
                {
                    writer.WriteLine();
                }
                writer.WriteLine(datos);
            }
            MessageBox.Show("Datos guardados con éxito\n\n" + datos, "información", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Tteléfono_TextChanged(object sender, EventArgs e)
        {

        }

        private void Bsalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            File.Delete("C:/Users/Hackerman/Documents/datos.txt");
            MessageBox.Show("Datos eliminados con éxito.");
        }
    }
}
