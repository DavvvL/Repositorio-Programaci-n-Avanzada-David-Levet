﻿namespace Celsius_Farenheit
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TCelsius = new System.Windows.Forms.TextBox();
            this.TFarenheit = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BLimpiar = new System.Windows.Forms.Button();
            this.CtoF = new System.Windows.Forms.Button();
            this.FtoC = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.AllowDrop = true;
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(761, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(37, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "X";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(200, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(376, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Conversor de Temperatura";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // TCelsius
            // 
            this.TCelsius.BackColor = System.Drawing.SystemColors.InfoText;
            this.TCelsius.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TCelsius.ForeColor = System.Drawing.SystemColors.Window;
            this.TCelsius.Location = new System.Drawing.Point(188, 169);
            this.TCelsius.Name = "TCelsius";
            this.TCelsius.Size = new System.Drawing.Size(108, 30);
            this.TCelsius.TabIndex = 2;
            this.TCelsius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TCelsius.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // TFarenheit
            // 
            this.TFarenheit.BackColor = System.Drawing.SystemColors.InfoText;
            this.TFarenheit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TFarenheit.ForeColor = System.Drawing.SystemColors.Window;
            this.TFarenheit.Location = new System.Drawing.Point(486, 169);
            this.TFarenheit.Name = "TFarenheit";
            this.TFarenheit.Size = new System.Drawing.Size(108, 30);
            this.TFarenheit.TabIndex = 3;
            this.TFarenheit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(211, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 22);
            this.label2.TabIndex = 4;
            this.label2.Text = "Celsius";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(499, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 22);
            this.label3.TabIndex = 5;
            this.label3.Text = "Farenheit";
            // 
            // BLimpiar
            // 
            this.BLimpiar.AllowDrop = true;
            this.BLimpiar.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BLimpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BLimpiar.Font = new System.Drawing.Font("Trebuchet MS", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BLimpiar.ForeColor = System.Drawing.Color.BurlyWood;
            this.BLimpiar.Location = new System.Drawing.Point(342, 169);
            this.BLimpiar.Name = "BLimpiar";
            this.BLimpiar.Size = new System.Drawing.Size(99, 37);
            this.BLimpiar.TabIndex = 6;
            this.BLimpiar.Text = "Limpiar";
            this.BLimpiar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.BLimpiar.UseVisualStyleBackColor = false;
            this.BLimpiar.Click += new System.EventHandler(this.button2_Click);
            // 
            // CtoF
            // 
            this.CtoF.AllowDrop = true;
            this.CtoF.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.CtoF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CtoF.Font = new System.Drawing.Font("Trebuchet MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CtoF.ForeColor = System.Drawing.Color.White;
            this.CtoF.Location = new System.Drawing.Point(228, 243);
            this.CtoF.Name = "CtoF";
            this.CtoF.Size = new System.Drawing.Size(68, 56);
            this.CtoF.TabIndex = 7;
            this.CtoF.Text = "->";
            this.CtoF.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.CtoF.UseVisualStyleBackColor = false;
            this.CtoF.Click += new System.EventHandler(this.CtoF_Click);
            // 
            // FtoC
            // 
            this.FtoC.AllowDrop = true;
            this.FtoC.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.FtoC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FtoC.Font = new System.Drawing.Font("Trebuchet MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FtoC.ForeColor = System.Drawing.Color.White;
            this.FtoC.Location = new System.Drawing.Point(486, 243);
            this.FtoC.Name = "FtoC";
            this.FtoC.Size = new System.Drawing.Size(68, 56);
            this.FtoC.TabIndex = 8;
            this.FtoC.Text = "<-";
            this.FtoC.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.FtoC.UseVisualStyleBackColor = false;
            this.FtoC.Click += new System.EventHandler(this.FtoC_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.FtoC);
            this.Controls.Add(this.CtoF);
            this.Controls.Add(this.BLimpiar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TFarenheit);
            this.Controls.Add(this.TCelsius);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TCelsius;
        private System.Windows.Forms.TextBox TFarenheit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BLimpiar;
        private System.Windows.Forms.Button CtoF;
        private System.Windows.Forms.Button FtoC;
    }
}

