﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Conersor_a_Texto_C_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool EnteroValido(string valor)
        {
            long resultado;
            return long.TryParse(valor, out resultado);
        }

        private bool TextoValido(string valor)
        {
            return Regex.IsMatch(valor, @"^[a-zA-Z\s]+$");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void Bguardar_Click(object sender, EventArgs e)
        {
            String nombre = Tnombre.Text;
            String apellidos = Tapellidos.Text;
            String telefono = Ttelefono.Text;
            String estatura = Testatura.Text;
            String edad = Tedad.Text;
            String sexo = " ";
            if (Rhombre.Checked)
            {
                sexo = "Hombre";
            }
            else if(Rmujer.Checked)
            {
                sexo = "Mujer";
            }

            if (TextoValido(nombre) && TextoValido(apellidos) && EnteroValido(telefono) && EnteroValido(estatura) && EnteroValido(edad) && sexo != " ")
            {

                String datos = $"Nombres {nombre}\r\nApellidos: {apellidos}\r\nTelefono: {telefono}\r\nEstatura: {estatura}\r\nEdad: {edad}\r\nSexo: {sexo}";

                String rutaArchivo = "C:/Users/Hackerman/Documents/datos.txt";
                bool archivoExiste = File.Exists(rutaArchivo);

                using (StreamWriter writer = new StreamWriter(rutaArchivo, true))
                {
                    if (archivoExiste)
                    {
                        writer.WriteLine();
                    }
                    writer.WriteLine(datos);
                }
                MessageBox.Show("Datos guardados con éxito\n\n" + datos, "información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (!TextoValido(nombre)){
                    MessageBox.Show("Nombre no valido");
                }
                if (!TextoValido(apellidos))
                {
                    MessageBox.Show("Apellidos no validos");
                }
                if (!EnteroValido(telefono))
                {
                    MessageBox.Show("Telefono no valido");
                }
                if (!EnteroValido(estatura))
                {
                    MessageBox.Show("Rstatura no valida");
                }
                if (!EnteroValido(edad))
                {
                    MessageBox.Show("Edad no valida");
                }
                if (sexo == " ")
                {
                    MessageBox.Show("Seleccione un sexo");
                }
            }
        }

        private void Tteléfono_TextChanged(object sender, EventArgs e)
        {
            if (EnteroValido(Ttelefono.Text))
            {
                Ttelefono.BackColor = Color.Green;
            }
            else {
                Ttelefono.BackColor = Color.Red;
            }
        }

        private void Bsalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            File.Delete("C:/Users/Hackerman/Documents/datos.txt");
            MessageBox.Show("Datos eliminados con éxito.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Tnombre.Text = null;
            Tapellidos.Text = null;
            Ttelefono.Text = null;
            Testatura.Text = null;
            Tedad.Text = null;
            Rhombre.Checked = false;
            Rmujer.Checked = false;
        }

        private void Rhombre_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void Tnombre_TextChanged(object sender, EventArgs e)
        {
            if (TextoValido(Tnombre.Text))
            {
                Tnombre.BackColor = Color.Green;
            }
            else
            {
                Tnombre.BackColor = Color.Red;
            }
        }

        private void Tapellidos_TextChanged(object sender, EventArgs e)
        {
            if (TextoValido(Tnombre.Text))
            {
                Tapellidos.BackColor = Color.Green;
            }
            else
            {
                Tapellidos.BackColor = Color.Red;
            }
        }

        private void Título_Click(object sender, EventArgs e)
        {

        }
    }
}
