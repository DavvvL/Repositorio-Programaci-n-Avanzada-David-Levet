from lib2to3.pytree import convert
import string
import tkinter as tk
import re

ventana = tk.Tk()
ventana.geometry("250x500")
ventana.title("Formulario Python V1")

var_genero = tk.IntVar()
from tkinter import messagebox

def validar_entero(valor):
    try: 
        int(valor)
        return True
    except: 
        return False
    
def validar_texto(texto):
    return bool(re.match("^[a-zA-Z]+$", texto))

def limpiar_campos():
    tbNombre.delete(0, tk.END)
    tbApellidos.delete(0, tk.END)
    tbEdad.delete(0, tk.END)
    tbEstatura.delete(0, tk.END)
    tbTelefono.delete(0, tk.END)
    var_genero.set(0)

def guardar_valores():
    nombre=tbNombre.get()
    apellido=tbApellidos.get()
    edad=tbEdad.get()
    estatura=tbEstatura.get()
    telefono=tbTelefono.get()
    genero = " "
    if var_genero.get()==1:
        genero = "Hombre"
    elif var_genero.get()==2:
        genero = "Mujer"
        
    if validar_entero(edad) and validar_entero(estatura) and validar_entero(telefono) and validar_texto(nombre) and validar_texto(apellido):
        datos = "Nombres: " + nombre + "\nApellidos: " + apellido + "\nEdad: " + edad + "\nEstatura: " + estatura + "\nTelefono: " + telefono + "\nGenero: " + genero + "\n\n"
        with open("C:/Users/Hackerman/Documents/DataFormulario.txt", "a") as archivo:
            archivo.write(datos+"\n\n")
        messagebox.showinfo("Estado","Datos guardados con exito: \n\n" + datos)
        limpiar_campos()
    else:
         messagebox.showinfo("Datos invalidos, revisar formato")
         limpiar_campos()

   

lbTitulo= tk.Label(ventana, text="Formulario", font='Times, 23')
lbTitulo.pack()

lbEspacio= tk.Label(ventana, text=" ", font='19')
lbEspacio.pack()

lbNombre= tk.Label(ventana, text="Nombre", font='Times, 12')
lbNombre.pack()
tbNombre= tk.Entry()
tbNombre.pack()

lbApellidos= tk.Label(ventana, text="Apellidos", font='Times, 12')
lbApellidos.pack()
tbApellidos= tk.Entry()
tbApellidos.pack()

lbEdad= tk.Label(ventana, text="Edad", font='Times, 12')
lbEdad.pack()
tbEdad= tk.Entry()
tbEdad.pack()

lbEstatura= tk.Label(ventana, text="Estatura", font='Times, 12')
lbEstatura.pack()
tbEstatura= tk.Entry()
tbEstatura.pack()

lbTelefono= tk.Label(ventana, text="Telefono", font='times, 12')
lbTelefono.pack()
tbTelefono= tk.Entry()
tbTelefono.pack()

lbEspacio2= tk.Label(ventana, text=" ", font='19')
lbEspacio2.pack()

lbGenero= tk.Label(ventana, text="Genero", font='times, 12')
lbGenero.pack()

rbHombre=tk.Radiobutton(ventana, text="Hombre", variable = var_genero, value = 1)
rbHombre.pack()

rbMujer=tk.Radiobutton(ventana, text="Mujer", variable = var_genero, value = 2)
rbMujer.pack()

btnBorrar= tk.Button(ventana, text="Limpiar", command=limpiar_campos)
btnBorrar.pack()
btnGuardar= tk.Button(ventana, text="Guardar", command=guardar_valores)
btnGuardar.pack()
btnSalir= tk.Button(ventana, text="Cerrar", command=ventana.destroy)
btnSalir.pack()

ventana.mainloop()